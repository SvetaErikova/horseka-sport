// let copyright_year = document.getElementById('js-current_year')
//
// copyright_year.textContent = new Date().getFullYear()
