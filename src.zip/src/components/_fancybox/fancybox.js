
Fancybox.bind('.gallery *[data-fancybox]', {
  infinite: false,
  groupAll: false,
  hideScrollbar: true,
})


