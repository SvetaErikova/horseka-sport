//
// /* Открытие дропдаунов */
// if ( window.matchMedia('(max-width:1023px)').matches ){
//   let dropdown = document.querySelectorAll('.is_dropdown')
//
//   dropdown.forEach(item => {
//     item.addEventListener('click', (e) => {
//       e.preventDefault()
//       e.currentTarget.classList.toggle('is_open')
//
//       window.addEventListener('scroll', ()=>{
//         item.classList.remove('is_open')
//       }, {once: true})
//     })
//   })
// }


