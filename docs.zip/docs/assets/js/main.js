// gsap.registerPlugin(ScrollTrigger);


let header = document.querySelector('.header ');
let note = document.querySelector('.note')

window.addEventListener('load', () => {
  let vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`)


    let scrollbar_width = window.innerWidth - document.documentElement.clientWidth
    document.documentElement.style.setProperty('--scrollbarWidth', `${scrollbar_width}px`)


  let header_height = header.getBoundingClientRect().height
  document.documentElement.style.setProperty('--headerHeight', `${header_height}px`)
  let note_height = note.getBoundingClientRect().height
  document.documentElement.style.setProperty('--noteHeight', `${note_height}px`)
});


window.addEventListener('resize', () => {
  let vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`)

  let header_height = header.getBoundingClientRect().height
  document.documentElement.style.setProperty('--headerHeight', `${header_height}px`)
  let note_height = note.getBoundingClientRect().height
  document.documentElement.style.setProperty('--noteHeight', `${note_height}px`)

})



/* Остановка видосов при выходе из экрана */
// window.onload = () => {
//   let video = document.querySelectorAll('.block:not(.block_banner) video')
//
//   let video_observer = new IntersectionObserver((entries) => {
//     entries.forEach(entry => {
//       let video = entry.target
//       // если видео запущено
//       if (!video.paused) {
//         // приостанавливаем проигрывание
//         video.pause()
//       } else {
//         // если видео было запущено ранее (текущее время проигрывания > 0)
//         video.pause()
//       }
//     })
//
//   }, { threshold: 0.7 })
//
//   if ( video.length > 1) {
//     video.forEach(v => {
//       video_observer.observe(v)
//     })
//   }
// }





// класс для создание таймера обратного отсчета
class CountdownTimer {
  constructor(deadline, cbChange, cbComplete) {
    this._deadline = deadline;
    this._cbChange = cbChange;
    this._cbComplete = cbComplete;
    this._timerId = null;
    this._out = {
      days: '', hours: '', minutes: '', seconds: '',
      // daysTitle: '', hoursTitle: '', minutesTitle: '', secondsTitle: ''
    };
    this._start();
  }
  static declensionNum (num, words) {
    return words[(num % 100 > 4 && num % 100 < 20) ? 2 : [2, 0, 1, 1, 1, 2][(num % 10 < 5) ? num % 10 : 5]];
  }
  _start(){
    this._calc();
    this._timerId = setInterval(this._calc.bind(this), 1000);
  }
  _calc(){
    const diff = this._deadline - new Date();
    const days = diff > 0 ? Math.floor(diff / 1000 / 60 / 60 / 24) : 0;
    const hours = diff > 0 ? Math.floor(diff / 1000 / 60 / 60) % 24 : 0;
    const minutes = diff > 0 ? Math.floor(diff / 1000 / 60) % 60 : 0;
    const seconds = diff > 0 ? Math.floor(diff / 1000) % 60 : 0;
    this._out.days = days < 10 ? '0' + days : days;
    this._out.hours = hours < 10 ? '0' + hours : hours;
    this._out.minutes = minutes < 10 ? '0' + minutes : minutes;
    this._out.seconds = seconds < 10 ? '0' + seconds : seconds;
    this._out.daysTitle = CountdownTimer.declensionNum(days, ['день', 'дня', 'дней']);
    this._out.hoursTitle = CountdownTimer.declensionNum(hours, ['час', 'часа', 'часов']);
    this._out.minutesTitle = CountdownTimer.declensionNum(minutes, ['минута', 'минуты', 'минут']);
    this._out.secondsTitle = CountdownTimer.declensionNum(seconds, ['секунда', 'секунды', 'секунд']);
    this._cbChange ? this._cbChange(this._out) : null;
    if (diff <= 0) {
      clearInterval(this._timerId);
      this._cbComplete ? this._cbComplete() : null;
    }
  }
}

let initTimers = (block) => {
  let timer_item = block.querySelectorAll('.js-timer')

  timer_item.forEach(t => {
    let deadline = new Date(Number(t.dataset.to))

    new CountdownTimer(deadline, (timer) => {
      t.textContent = timer.days + " : " + timer.hours  + " : " + timer.minutes  + " : " + timer.seconds;
    }, () => {
      t.textContent = 'Завершено!';
    });
  })
}
initTimers(document)




let blockCalendar = document.querySelector('.content_events-calendar')
if(blockCalendar){
  let numberOfMonths = 3
  if ( window.matchMedia('(max-width: 575px)').matches ) {
    numberOfMonths = 1
  } else if(window.matchMedia('(max-width: 1024px)').matches){
    numberOfMonths = 2
  } else{
    numberOfMonths = 3
  }

  let btnReset = blockCalendar.querySelector('.block--calendar .reset-button')
  let blockSection = blockCalendar.querySelector('.block--sections')
  let input = document.getElementById('datepicker')

  let ALLOWEDDATES = [];
  if (  ALLOWEDDATES.length < 1 ){
    ALLOWEDDATES = [
      // '2024-05-07', '2024-05-08', '2024-05-09',
      // '2024-05-11', '2024-05-13', '2024-05-15',
    ];
  } else {
    ALLOWEDDATES = {...ALLOWEDDATES}
  }

  // PRELODER


  // CALENDAR
  let calendar = new Litepicker({
    element: input,
    inlineMode: true,
    numberOfMonths: numberOfMonths,
    numberOfColumns: numberOfMonths,
    singleMode: true,
    lang: 'RU',
    splitView: false,
    lockDaysFilter: (date1, date2, pickedDates) => {
      return !ALLOWEDDATES.includes(date1.format('YYYY-MM-DD'));
    },
    setup: (picker) => {
      picker.on('selected', (date1, date2) => {
        let date = new Date(input.value).toLocaleString('ru', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
        btnReset.querySelector('.date').innerText = date
        btnReset.classList.add('is_active')
        blockSection.classList.add('hidden')
      });
    },
  })

  // RESET
  btnReset.addEventListener('click', (btn) =>{
    btnReset.classList.remove('is_active')
    blockSection.classList.remove('hidden')
    calendar.clearSelection()
  })
  // TABS
  let  tabs = blockCalendar.querySelectorAll('.block--sections button')
  tabs.forEach(tab =>{
    tab.addEventListener('click', (e) =>{
      e = e.currentTarget.dataset.date
      calendar.gotoDate(e)
    })
  })

  let filterReset = blockCalendar.querySelector('.filter [type="reset"]')
  filterReset.addEventListener('click', (e)=>{
    calendar.clearSelection()
    // ALLOWEDDATES = [
    //   '2024-07-07', '2024-07-08', '2024-07-09',
    //   '2024-07-11', '2024-07-13', '2024-05-15',
    // ];
    calendar.setOptions(ALLOWEDDATES)
  })

  // FILTERS
  window.addEventListener('load', (e) => {
    let filterSelect = blockCalendar.querySelectorAll('.filter .select--option')
    filterSelect.forEach(s =>{
      s.addEventListener('click', (e) =>{
        // ALLOWEDDATES = [
        //   '2024-06-07', '2024-06-08', '2024-05-09',
        //   '2024-06-11', '2024-06-13', '2024-05-15',
        // ];
        // calendar.clearSelection()
        btnReset.click()
        calendar.setOptions(ALLOWEDDATES)
      })
    })
  })

}

// console.log(calendar)

// let copyright_year = document.getElementById('js-current_year')
//
// copyright_year.textContent = new Date().getFullYear()

Inputmask({
  mask: "+7 999 999 99 99",
  inputmode: 'numeric',
  showMaskOnFocus: true,
  "clearIncomplete": true,
  clearMaskOnLostFocus: true,
  greedy: false,
  nullable: true,
}).mask("input[type='tel']");

function returnFileSize(number) {
  if (number < 1024) {
    return `${number} bytes`;
  } else if (number >= 1024 && number < 1048576) {
    return `${(number / 1024).toFixed(1)} KB`;
  } else if (number >= 1048576) {
    return `${(number / 1048576).toFixed(1)} MB`;
  }
}

function validateInputs(form) {
  let inputs = form.querySelectorAll('input:not([type="hidden"])')
  let submit_button = form.querySelector('button[type="submit"]')

  inputs.forEach(i => {
    let parent = i.closest('.form--input');
    let error_text = parent.querySelector('.form--input_error')

    if ( i.classList.contains('js-input_file') ){

      let file_text = i.parentElement.querySelector(".js-changeDescriptionText")
      let changeFileButton = i.parentElement.querySelector(".js-clearFile")
      let input_max_size = parseInt(i.dataset.maxsize)

      i.addEventListener("change", function(){
        file_text.textContent = i.files.item(0).name + " (" + returnFileSize(this.files[0].size) + ")";
        i.parentElement.classList.add("loaded");

        if ( this.files[0].size > input_max_size) {
          i.setCustomValidity("Файл слишком большой")
          i.reportValidity(false)
        }
      })

      changeFileButton.addEventListener("click", function(e){
        e.stopPropagation()
        e.preventDefault()

        i.value = ""
        i.parentElement.classList.remove("loaded")
        file_text.innerHTML = file_text.dataset.text || "Выберите файл в допустимом формате ("+ i.accept+ "), размером не более " + returnFileSize(input_max_size)
      })
    }

    if ( i.parentElement.classList.contains('js-toggle') ){
      let toggle = i.parentElement
      let hidden_value = toggle.querySelector('input[type="hidden"]').value
      let toggle_text_element = toggle.querySelector('span')

      i.addEventListener('change', ()=>{
        i.checked
          ? toggle_text_element.textContent = i.value
          : toggle_text_element.textContent = hidden_value
      })
    }

    i.addEventListener('change', ()=>{


      if ( !i.checkValidity() ) {

        i.setAttribute("invalid", '');
        i.removeAttribute("valid", '');

        parent ? parent.classList.add('error') : null;

        if ( i.validity.valueMissing ) {
          error_text ? error_text.textContent = "Данное поле обязательно к заполнению" : "";
        }
        else if ( i.validity.patternMismatch || i.validity.typeMismatch ) {
          error_text ? error_text.textContent = "Проверьте правильность заполнения поля" : "";
        }
        else if ( i.validity.rangeOverflow ) {
          error_text ? error_text.textContent = "Проверьте правильность заполнения поля" : "";
        }
        else if ( i.validity.rangeUnderflow ) {
          error_text ? error_text.textContent = "Проверьте правильность заполнения поля" : "";
        }
        else if (i.validity.customError){
          error_text ? error_text.textContent = "Файл слишком большой" : "";
        }
        else {
          error_text ? error_text.textContent = "Данное поле не заполнено или заполнено неверно" : "";
        }

        form.checkValidity()
          ? submit_button.removeAttribute('disabled')
          : submit_button.setAttribute('disabled', "")
      }
      else {

        i.removeAttribute("invalid", '');
        i.setAttribute("valid", '');

        form.checkValidity()
        ? submit_button.removeAttribute('disabled')
          : submit_button.setAttribute('disabled', "")

        parent ? parent.classList.remove('error') : null;
        error_text ? error_text.textContent = "Данное поле не заполнено или заполнено неверно" : "";
      }


    })

  })

}

let forms = document.querySelectorAll('form')

forms.forEach(form => {
  validateInputs(form)
})



//date input

// let date_inputs = document.querySelectorAll('.form--input_date')
//
// date_inputs.forEach( input => {
//
//   let i_today_date = new Date()
//   // i_today_date.setDate(i_today_date.getDate() - 1);
//
//   const picker = new Litepicker({
//     element: input,
//     singleMode: true,
//     autoApply: true,
//     format: 'DD.MM.YYYY',
//     lang: "ru-RU",
//     // startDate: i_today_date,
//     minDate: input.dataset.min,
//     maxDate: input.dataset.max,
//     position: 'left auto',
//     numberOfMonths: 1,
//     numberOfColumns: 1,
//     showTooltip: false,
//     plugins: ['mobilefriendly'],
//     mobilefriendly: {
//       breakpoint: 668,
//     },
//     buttonText: {
//       "previousMonth": '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">\n' +
//         '<path d="M6.43359 11.4343L14.4336 3.43433L15.565 4.5657L8.13065 12L15.565 19.4343L14.4336 20.5657L6.43359 12.5657V11.4343Z" />\n' +
//         '</svg>',
//       "nextMonth": '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">\n' +
//         '<path d="M17.565 11.4343L9.56496 3.43433L8.43359 4.5657L15.8679 12L8.43359 19.4343L9.56496 20.5657L17.565 12.5657V11.4343Z" />\n' +
//         '</svg>',
//     },
//     setup: (picker) => {
//       picker.on('before:render', (ui) => {
//         input.placeholder = i_today_date.toLocaleDateString("ru-RU")
//       });
//     },
//   });
// })

let createCustomSelect = ( block ) =>{
  let select_inputs = block.querySelectorAll('.form--input_select')

  select_inputs.forEach(i => {

    let select = document.createElement('div')
    select.classList.add('select')
    i.appendChild(select)

    let select_button = document.createElement('div')
    select_button.classList.add('select--button')
    select.appendChild(select_button)

    let select_option_list_container = document.createElement('div')
    select_option_list_container.classList.add('select--option_wrapper')
    select.appendChild(select_option_list_container)

    let select_option_list = document.createElement('div')
    select_option_list.classList.add('select--option_list')
    select_option_list_container.appendChild(select_option_list)


    let options = i.querySelectorAll('option')

    options.forEach(opt => {
      let customCheckbox = document.createElement('div')
      customCheckbox.classList.add('select--checkbox')
      let select_option = document.createElement('div')
      select_option.classList.add('select--option')
      select_option.dataset.value = opt.value
      select_option.textContent = opt.value
      select_option.appendChild(customCheckbox)
      select_option_list.appendChild(select_option)

    })

    let select_options = i.querySelectorAll('.select--option')
    select_options.forEach((option,index) => {
      option.addEventListener('click',(op)=>{
        select_button.textContent = option.dataset.value
        select_options.forEach(o => {
          o !== option ? o.classList.remove('is_selected') : o.classList.add('is_selected')
        })
        select_option_list_container.classList.remove('is_opened')
        options.forEach(opt => {
          op.currentTarget.dataset.value === opt.value ? opt.setAttribute('selected', '') : opt.removeAttribute('selected', '')
        })
      })
    })

    select_button.textContent = options[0].value

    // select_button.addEventListener('click',()=>{
    //   select_option_list_container.classList.toggle('is_opened')
    // })

  })
  let selectBtn = block.querySelectorAll('.select--button')
  selectBtn.forEach(sel =>{
    sel.addEventListener('click', (e) =>{
      selectBtn.forEach(se =>{
        let s = se.parentElement.querySelector('.select--option_wrapper')
        se === e.currentTarget ? s.classList.toggle('is_opened')  : s.classList.remove('is_opened')

      })
    })
  })
  let selects = block.querySelectorAll('.select')
  selects.forEach(s =>{
  window.addEventListener("keydown", function (e) {

      if (e.code === "Escape") {


        s.querySelector('.select--option_wrapper').classList.remove('is_opened')

      }
    })
    window.addEventListener("click", function (e) {
      if (e.target !== s ){
          if ( e.target.closest('.form--input_select') === null ) {
            s.querySelector('.select--option_wrapper').classList.remove('is_opened')
          }
      }
    });


  });
}

createCustomSelect(document)


function checkSelect(){
  let select_inputs = document.querySelectorAll('.form--input_select')

    select_inputs.forEach(i => {
    let select_options = i.querySelectorAll('.select--option')
      let options = i.querySelectorAll('option')
    select_options.forEach((option,index) => {
      option.addEventListener('click',(op)=>{
        // select_button.textContent = option.dataset.value
        select_options.forEach(o => {
          o !== option ? o.classList.remove('is_selected') : o.classList.add('is_selected')
        })
        options.forEach(opt => {
          op.currentTarget.dataset.value === opt.value ? opt.setAttribute('selected', '') : opt.removeAttribute('selected', '')
        })
      })
    })
  })
}

/* Скролл хедера */
let last_scroll = 0;

window.addEventListener('scroll', (e) => {
  if ( window.matchMedia('(max-width: 992px)').matches ) {
    // let current_scroll = window.pageYOffset || document.documentElement.scrollTop;
    //
    // current_scroll >= last_scroll && current_scroll
    //   ? header.classList.add('scrolled-up')
    //   : header.classList.remove('scrolled-up')
    //
    // last_scroll = current_scroll
  }

  document.documentElement.scrollTop > 0
    ? header.classList.add('is_scrolled')
    : header.classList.remove('is_scrolled')

})

window.addEventListener('load', (e) => {
  document.documentElement.scrollTop > 0
    ? header.classList.add('is_scrolled')
    : header.classList.remove('is_scrolled')
})


/* Меню в хедере */
let menu_items = document.querySelectorAll('.popup-menu .nav--item.is_dropdown')

menu_items.forEach( item => {


  item.addEventListener('click', (e)=>{
      menu_items.forEach(it => {
      e.preventDefault()
      it === e.currentTarget ? it.classList.toggle('is_open') : it.classList.remove('is_open')
    })
  })


  // if ( window.matchMedia('(max-width: 992px)').matches ) {
  //   let menu_link =  item.querySelector('.nav--item')
  //
  //   if ( menu_link ) {
  //     console.log(menu_link)
  //     menu_link.addEventListener('click', (e) => {
  //       e.preventDefault()
  //     })
  //   }
  //   item.addEventListener('click', (e)=>{
  //     if ( !item.classList.contains('is_open')  ) {
  //       item.classList.add('is_open')
  //     }
  //   })
  //
  // }

})

function isOverflown(element) {

  let headerWidth = document.querySelector('.header--logo').clientWidth + document.querySelector('.header--actions').clientWidth

  // return element.clientWidth >  headerWidth;
}

/* Навигация в хедере */

if ( window.matchMedia('(min-width: 1024px)').matches ) {

  let header_nav = document.querySelector('.header--nav')
  let nav = header_nav.querySelector('.nav')
  // console.log(header_nav)
  let dropdown_button = header_nav.querySelector('.nav--item.showMore')
  let dropdown_menu = dropdown_button.querySelector('.is_dropdown--wrapper .is_dropdown--content')

  function hideOverflownElements() {
    let nav_items = header_nav.querySelectorAll('.nav > .nav--item:not(.showMore)')
    let last_link = nav_items[nav_items.length - 1]
    nav.removeChild(last_link)
    dropdown_menu.appendChild(last_link)
    dropdown_button.classList.remove('hidden')
  }

  function showOverflownElements() {
    let last_link = dropdown_menu.firstChild
    if (last_link ){
      dropdown_menu.removeChild(last_link)
      nav.appendChild(last_link)
      dropdown_button.classList.add('hidden')
    }
  }

  if ( isOverflown(header_nav) ) {
    while( isOverflown(header_nav) ){
      hideOverflownElements()
    }
  }
  // else {
  //
  //     // showOverflownElements()
  //
  // }

  window.addEventListener('resize', ()=>{
    if ( isOverflown(header_nav) ) {
      while( isOverflown(header_nav) ){

        hideOverflownElements()
      }
    }
    // else {
    //   while( !isOverflown(header_nav) ){
    //     showOverflownElements()
    //   }
    // }
  })

}



//
// /* Открытие дропдаунов */
// if ( window.matchMedia('(max-width:1023px)').matches ){
//   let dropdown = document.querySelectorAll('.is_dropdown')
//
//   dropdown.forEach(item => {
//     item.addEventListener('click', (e) => {
//       e.preventDefault()
//       e.currentTarget.classList.toggle('is_open')
//
//       window.addEventListener('scroll', ()=>{
//         item.classList.remove('is_open')
//       }, {once: true})
//     })
//   })
// }



let map_contacts = document.getElementById('map')
if(map_contacts){
  ymaps = window.ymaps;
  ymaps.ready(init);
  function init(){
    var myMap = new ymaps.Map("map", {
      center: [56.026875, 38.279307],
      zoom: 12,
      controls: ['zoomControl'],
    });


    myMap.geoObjects
      .add(new ymaps.Placemark([56.026875, 38.279307], {
        balloonContent: 'Horseka resort',
        hintContent: 'Horseka resort'
      }, {
        iconLayout: 'default#imageWithContent',
        iconImageHref: '/assets/img/vector.svg',
        iconImageSize: [48, 48],
        iconImageOffset: [-12, -12],
      }))

    myMap.behaviors.disable('scrollZoom')
    if ( window.matchMedia("(max-width: 768px)").matches ) {
      myMap.behaviors
        .disable('drag')
        .enable('multiTouch');
    }
  }

}

if (note){

  window.addEventListener('load', ()=>{
    // if ( localStorage.getItem('popState') !== 'shown' ) {
    //   note.style.display = 'block'
    //     localStorage.setItem('popState','shown')
    // }
    // note.style.display = 'block'
  })
  note.querySelector('.note-close').addEventListener('click', e =>{
    note.classList.add('hidden')
  })

}



PopupManager.register('popup_for_form', {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_close: (popup_element, params) => {
      popup_element.querySelector('form').reset();
    }
  }
);
PopupManager.register('popup_for_cookies', {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_close: (popup_element, params) => {

    }
  }
);
PopupManager.register('popup_for_filters', {
    additional_close_controls: false,
    is_block_scroll: true,
  },
  {
    on_open: (popup_element, params) => {
      let block_to_clone = params.block;
      let block_content = block_to_clone.cloneNode(true);
      popup_element.querySelector('.popup--form').appendChild(block_content);
      checkSelect()
      resetSelect(popup_element)

      // resetSelect(popup_element)
    },
    on_close: (popup_element, params) => {
      setTimeout(() =>
        popup_element.querySelector('.popup--form').innerHTML = ""
      , 180)
    }
  }
);
// PopupManager.register('popup_for_balloon',{
//     is_block_scroll: true,
//     close_controls: false,
//   },{
//     on_open: (popup_element, params) => {
//       popup_element.querySelector('.balloon--image img').src = params.placemark.balloonImage;
//       popup_element.querySelector('.balloon--title').textContent = params.placemark.balloonHeader;
//       popup_element.querySelector('.balloon--text').textContent = params.placemark.balloonContent;
//       popup_element.querySelector('a').href = params.placemark.balloonLink;
//     },
//   }
// );

// PopupManager.register('popup_for_scheme',{
//     is_block_scroll: true,
//     close_controls: false,
//   },
//   {
//     on_open: (popup_element, params) => {
//       let title = popup_element.querySelector('.popup__content-title'),
//         description = popup_element.querySelector('.popup__content-text'),
//         image = popup_element.querySelector('img'),
//         link = popup_element.querySelector('.js-popup--sheme_link'),
//         tour = popup_element.querySelector('.js-popup--sheme_tour')
//
//       let scheme_object = SCHEME_PLACEMARKS[params.id] ? SCHEME_PLACEMARKS[params.id] : SCHEME_PLACEMARKS[0]
//
//       title.textContent = scheme_object.title;
//       description.textContent = scheme_object.description;
//       image.src = scheme_object.image;
//       link.href = scheme_object.link;
//       tour.href = scheme_object.tour;
//     }
//   }
// );



PopupManager.register('popup_menu',{
    is_block_scroll: true,
    close_controls: false,
  },
  {
    on_open: (popup_element, params)=>{
      if ( window.matchMedia('(min-width: 992px)').matches ) {
        document.documentElement.scrollTop > 0
          ? popup_element.style.paddingTop = header.querySelector('.header--main').getBoundingClientRect().height + "px"
          : popup_element.style.paddingTop = header.getBoundingClientRect().height + "px"
      }
      header.classList.add('is_menu_opened')

      if ( window.matchMedia('(min-width: 1024px)').matches ) {
        menu_items[0].classList.add('is_open')
      }

    },
    on_close: (popup_element, params) => {
      header.classList.remove('is_menu_opened')
      menu_items.forEach( item => {
        item.classList.remove('is_open')
      })
    }
  }
);


PopupManager.register('popup_cascade',
  {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_open: (popup_element, params) => {
      // popup_element.querySelector('.is_cascade').innerHTML = "123"
    },
    on_close: (popup_element, params) =>{
      setTimeout(()=>{
        popup_element.querySelector('.is_cascade').innerHTML = ""
      }, 180)

    }
  }
);
PopupManager.register('popup_for_infrastructure',{
    is_block_scroll: false,
    close_controls: false,
  },
  {
    on_open: (popup_element, params) => {

      let title = popup_element.querySelector('.popup--content-title'),
        description = popup_element.querySelector('.popup--content-text'),
        image = popup_element.querySelector('img'),
        link = popup_element.querySelector('.js-popup--infrastructure_link'),
        tour = popup_element.querySelector('.js-popup--infrastructure_other')

      let infrastructure_object = INFRASTRUCTURE_PLACEMARKS[params.id] ? INFRASTRUCTURE_PLACEMARKS[params.id] : INFRASTRUCTURE_PLACEMARKS[0]

      title.textContent = infrastructure_object.title;
      description.textContent = infrastructure_object.description;
      image.src = infrastructure_object.image;
      link.href = infrastructure_object.link;
      tour.href = infrastructure_object.other;
    }
  }
);

// Tour Map
PopupManager.register('popup_for_tour',{
    is_block_scroll: false,
    close_controls: false,
  },{
    on_open: (popup_element, params) => {
      popup_element.querySelector('.popup--content-title').textContent = params.placemark.balloonHeader;
      popup_element.querySelector('.popup--content-text').textContent = params.placemark.balloonContent;
    },
  }
);

// Add event Listeners to open Popups
// Элемент (data-openpopup=""), где data-openpopup = popup.name

let open_popup_buttons = document.querySelectorAll('[data-openpopup]');

function activatePopupButtons(buttons){
  buttons.forEach(b => {

    b.addEventListener('click', (e)=>{
      e.preventDefault();

      if ( b.dataset.openpopup === "popup_for_filters") {
        let block_to_clone = b.parentElement.querySelector('.filter');
        if (block_to_clone) {
          PopupManager.open(b.dataset.openpopup, {block: block_to_clone})
        }
      }
      else if ( b.dataset.openpopup === "popup_for_infrastructure" ) {
          PopupManager.open(b.dataset.openpopup, {
            id: b.dataset.id ? b.dataset.id : '0'
          })
        } else{
        PopupManager.open(b.dataset.openpopup);
      }


    })

  });
}

activatePopupButtons(open_popup_buttons)


/* Open popup after page loaded*/
window.addEventListener('load', ()=>{
  // PopupManager.open('popup_for_cookies')
  // PopupManager.open('popup_for_form')
})

/* Open popup after page loaded 1 time per session */
window.addEventListener('load', ()=>{
  if ( localStorage.getItem('popState') !== 'shown' ) {

  //   active_manager.openPopup('popup_for_welcoming')
  //   localStorage.setItem('popState','shown')
  }
})


let menu_button = document.querySelectorAll('.menu_button');

menu_button.forEach(b => {
  b.addEventListener('click', (e)=>{

    if ( document.querySelector('.popup[data-popup="popup_menu"]').classList.contains("is_active") ) {
      PopupManager.close("popup_menu")
    }
    else {
      PopupManager.open("popup_menu")
    }

  })
})


let scheme = document.querySelector('.content_scheme')

if ( scheme ) {
  let svg = scheme.querySelector('.scheme')
  let legend = scheme.querySelector('.scheme_legend')
  let legend_button = scheme.querySelector('.scheme_legend--title')
  let legend_filters = scheme.querySelector('.scheme_legend--dropdown')

  legend_button.addEventListener('click', ()=>{
    legend.classList.toggle('is_active')

  })

  /* Инстаточки, фото на ховер на точку*/
  let photo_placemarks = scheme.querySelectorAll('.placemark_photo')

  photo_placemarks.forEach(item => {
    let image_wrapper = document.createElement('div')
    let image = document.createElement('img')
    image_wrapper.appendChild(image)

    item.addEventListener('mouseover', (e)=>{
      image_wrapper.classList.add('is_active')
      image_wrapper.classList.add('placemark_photo--image')
      image.src = item.dataset.src

      scheme.append(image_wrapper)

      if ( e.clientX > window.innerWidth/2 ) {
        image_wrapper.style.cssText = `
          left:${(e.clientX)}px;
          top:${(e.clientY)}px;
          transform: translate(calc(-100% - 24px), 16px)
        `
      }
      else {
        image_wrapper.style.cssText = `
          left:${(e.clientX)}px;
          top:${(e.clientY)}px;
          transform: translate(24px, 16px)
        `
      }
    })

    item.addEventListener('mouseleave', (e)=>{
      image_wrapper.classList.remove('is_active')
    })

    if ( window.matchMedia('(max-width:992px)').matches ) {

      item.addEventListener('click', (e)=>{
        image_wrapper.classList.add('is_active')
        console.log('is_active')
        image_wrapper.classList.add('placemark_photo--image')
        image.src = item.dataset.src

        scheme.append(image_wrapper)

        setTimeout(()=>{
          image_wrapper.classList.remove('is_active')
        }, 3000)
        window.addEventListener('scroll', ()=>{
          image_wrapper.classList.remove('is_active')
        }, {once: true})
      })

    }

  })

  /* Точки объектов и фильтры */
  let placemarks = scheme.querySelectorAll('.placemark')
  let placemarks_filters = scheme.querySelectorAll('.scheme_legend--filter')


  placemarks_filters.forEach(filter => {
    filter.addEventListener('click', ()=>{
      placemarks_filters.forEach(i => {
        i === filter? i.classList.add('is_active') : i.classList.remove('is_active')
      })

      placemarks.forEach(pm => {
        if ( filter.dataset.type === "all"){
          pm.classList.remove('is_hidden')
        }
        else {
          pm.dataset.type === filter.dataset.type ? pm.classList.remove('is_hidden') : pm.classList.add("is_hidden")
        }
      })
    })
  })
  function getCoords(pm){
    return  pm.getBBox();
  }
  function getCoeff(){
    return  svg.getBoundingClientRect().width / 1920
  }

  placemarks.forEach(pm => {
    let tooltip = document.createElement('div');
    let tooltip_title = document.createElement('h3')

    scheme.append(tooltip);
    tooltip.append(tooltip_title)

    tooltip.classList.add('scheme--tooltip');

    let title;
    pm.dataset.title ? title = pm.dataset.title : title = "Заголовок метки"
    tooltip_title.textContent = title;

    let coords = getCoords(pm);
    let coeff = getCoeff();

    tooltip.style.cssText = `left:${(coords.x*coeff)+(pm.getBBox().width*coeff / 2)}px;top:${(coords.y*coeff)}px;`

    pm.addEventListener('mouseover', (e)=>{
      tooltip.classList.add('is_visible')
    })

    pm.addEventListener('mouseleave', (e)=>{
      tooltip.classList.remove('is_visible')
    })
  })

  if ( window.matchMedia('(max-width:992px)').matches ){

    let scheme_panzoom = new Panzoom(scheme.querySelector('.content_scheme--scheme'), {
      click: false,
      wheel: false,
      maxScale: 4,
      minScale: 2,
      step: 0.5,
      bounce: false,
      panOnlyZoomed: true,
      on: {
        ready: (instance) => {
          instance.zoomToCover()
        }
      },
      bounds: {
        top: 0,
        bottom: 0
      }
    });
    scheme_panzoom.toggleZoom()
    scheme_panzoom.zoomToCover()

  }

  if ( scheme.classList.contains('js_copyCoords') ){
    let coords_tooltip = document.createElement('div')
    coords_tooltip.classList.add('coords_tooltip')
    scheme.appendChild(coords_tooltip)

    let pt = svg.createSVGPoint();

    svg.addEventListener('click', (e)=>{
      pt.x = e.clientX;
      pt.y = e.clientY;


      let cursorpt =  pt.matrixTransform(svg.getScreenCTM().inverse());

      coords_tooltip.style =
        "left:"+(e.clientX)
        +"px;top:"+ (e.clientY) + "px"

      coords_tooltip.textContent =
        "Координаты клика - x: "
        + Math.round(cursorpt.x)
        + "; y: "+ Math.round(cursorpt.y)
        + ". Координаты скопированы!"

    })
  }
}


Fancybox.bind('.gallery *[data-fancybox]', {
  infinite: false,
  groupAll: false,
  hideScrollbar: true,
})




/* Page navigation Company */

let block_with_navigation = document.querySelector(".sidebar");
if ( block_with_navigation ) {

  let anchor_links = block_with_navigation.querySelectorAll('a');
  console.log(anchor_links)
  anchor_links.forEach(link => {
    link.addEventListener("click", (event) => {
      event.preventDefault();

      let hash = event.currentTarget.hash.substring(1);
      console.log(hash)

      let target = document.querySelector('a[name="'+hash+'"]');

      target.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    });
  });

  let callback = (entries, observer) => {
    entries.forEach(entry => {
      let link = document.querySelector("a[href='#"+ entry.target.name +"']");

      if ( entry.isIntersecting ) {
        link.classList.add("is_active")

      } else {
        link.classList.remove("is_active")
      }

    })
  }

  let observer = new IntersectionObserver(callback, {
    root: null,
    rootMargin: '0px 0px -40% 0px',
    threshold: [0.5]
  });


  window.addEventListener("scroll", (event) => {

    anchor_links.forEach(link => {

      let hash = link.hash.substring(1)

      let section = document.querySelector('a[name="'+hash+'"]');
      if ( section ) observer.observe(section);
    });

  });
}

let banner_slider = document.querySelectorAll('.block_banner-group');

banner_slider.forEach(banner_sl => {

  if ( banner_sl.classList.contains('block_banner-hero') ) {
    let slider_controls = document.createElement('div');
    slider_controls.classList.add('slider_controls');
    banner_sl.append(slider_controls);

    let swiper_pagination = document.createElement('div');
    swiper_pagination.classList.add('swiper-pagination');
    slider_controls.append(swiper_pagination);

    let swiper_nav_prev = document.createElement('div');
    swiper_nav_prev.classList.add('swiper--prev' ,'button', 'button-outlined','button-secondary','button-dark');
    slider_controls.append(swiper_nav_prev);

    let swiper_nav_next = document.createElement('div');
    swiper_nav_next.classList.add('swiper--next','button', 'button-outlined','button-secondary','button-dark');
    slider_controls.append(swiper_nav_next);




    const hero_slider = new Swiper(banner_sl.querySelector('.block--wrapper'), {
      createElements: true,
      slideClass: 'banner',
      slidesPerView: 1,
      grabCursor: false,
      simulateTouch: true,
      allowTouchMove: true,
      centeredSlides: true,
      focusableElements: 'a, button',
      loop: false,
      mousewheel: {
        forceToAxis: true,
      },
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      pagination: {
        el: swiper_pagination,
        clickable: true
      },

    });


  }
  else {
    let slider_controls = document.createElement('div');
    slider_controls.classList.add('slider_controls');


    let swiper_pagination_container = document.createElement('div');
    swiper_pagination_container.classList.add('swiper-pagination-container');
    slider_controls.append(swiper_pagination_container);

    let swiper_pagination = document.createElement('div');
    swiper_pagination.classList.add('swiper-pagination');
    swiper_pagination_container.append(swiper_pagination);

    let swiper_nav_prev = document.createElement('div');
    swiper_nav_prev.classList.add('swiper--prev','button', 'button-outlined','button-secondary');
    slider_controls.append(swiper_nav_prev);

    let swiper_nav_next = document.createElement('div');
    swiper_nav_next.classList.add('swiper--next','button', 'button-outlined','button-secondary');
    slider_controls.append(swiper_nav_next);

    const banner_slider = new Swiper( banner_sl.querySelector('.block--wrapper'), {
      createElements: true,
      slideClass: 'banner',
      slidesPerView: 1,
      grabCursor: false,
      simulateTouch: true,
      allowTouchMove: true,
      centeredSlides: true,
      effect: 'slide',
      spaceBetween: 24,
      mousewheel: {
        forceToAxis: true,
      },
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      pagination: {
        el: swiper_pagination,
        type: "progressbar",
      },
      focusableElements: 'a, button',
    });
    banner_sl.querySelector('.block--wrapper').append(slider_controls);
  }
})


/* Block_list slider Слайдеры в списках */
let  activateBlocklistSlider = (block) => {
  let swiper_block = block.querySelectorAll('.block_list-slider');

  swiper_block.forEach(swiper_item => {

    if ( swiper_item.classList.contains('block_list-slider-v2') ) {

      let head = swiper_item.querySelector('.block--head')

      let slider_controls = document.createElement('div');
      slider_controls.classList.add('slider_controls');

      let swiper_nav_prev = document.createElement('div');
      swiper_nav_prev.classList.add('swiper-button-prev','button', 'button-outlined','button-secondary','button-dark');
      slider_controls.append(swiper_nav_prev);

      let swiper_nav_next = document.createElement('div');
      swiper_nav_next.classList.add('swiper-button-next','button', 'button-outlined','button-secondary','button-dark');
      slider_controls.append(swiper_nav_next);

      let swiper_pagination = document.createElement('div');
      swiper_pagination.classList.add('swiper-pagination');
      slider_controls.append(swiper_pagination);

      const swiper = new Swiper(swiper_item.querySelector('.block--elements'), {
        createElements: true,
        slideClass: 'card',
        grabCursor: true,
        simulateTouch: true,
        freeMode: false,
        allowTouchMove: true,
        uniqueNavElements: true,
        // loop: true,
        focusableElements: 'input, select, option, textarea, button, video, label, a, button',
        noSwipingClass: "swiper-no-swiping-block",
        mousewheel: {
          forceToAxis: true,
        },
        navigation: {
          nextEl: swiper_nav_next,
          prevEl: swiper_nav_prev,
        },
        pagination: {
          el: swiper_pagination,
          clickable: true
        },
        breakpoints: {
          280: {
            spaceBetween: 8,
            slidesPerView: 1,
          },
          640: {
            spaceBetween: 20,
            slidesPerView: 2,
          },
          1140: {
            spaceBetween: 20,
            slidesPerView: 2.5,
          },
        },
      });
      head.append(slider_controls);

      if (swiper.slides.length <= 3) {
        // slider_controls.classList.add('hidden')

        // swiper.navigation.nextEl.classList.add('hidden')
        // swiper.navigation.prevEl.classList.add('hidden')
        swiper.disable()
      }


    }
    else if( swiper_item.classList.contains('block_list-slider')){
      let slides_per_view_desktop = 4, slides_per_view_pad = 3, slides_per_view_mob = 1.2;

      switch (true) {
        case swiper_item.classList.contains('content_offers'):
          slides_per_view_desktop = 2;
          slides_per_view_pad = 2;
          slides_per_view_mob = 1.3;
          break;
        case swiper_item.classList.contains('content_basic'):
          slides_per_view_desktop = 4;
          slides_per_view_pad = 3;
          slides_per_view_mob = 1.1;
          break;
        case swiper_item.classList.contains('content_hourse'):
          slides_per_view_desktop = 2;
          slides_per_view_pad = 1.2;
          slides_per_view_pad = 1.1;
          break;
        case swiper_item.classList.contains('content_personal'):
          slides_per_view_desktop = 4;
          slides_per_view_pad = 3;
          slides_per_view_mob = 1.1;
          break;
        case swiper_item.classList.contains('content_advantages'):
          slides_per_view_desktop = 3;
          slides_per_view_pad = 2.2;
          slides_per_view_mob = 1.1;
          break;
        case swiper_item.classList.contains('content_reviews'):
          slides_per_view_desktop = 3;
          slides_per_view_pad = 2.2;
          slides_per_view_mob = 1.1;
          break;
        case swiper_item.classList.contains('content_news'):
          slides_per_view_desktop = 3;
          slides_per_view_pad = 2.2;
          slides_per_view_mob = 1.1;
          break;
        default:
          slides_per_view_desktop = 4;
          slides_per_view_pad = 2;
          slides_per_view_mob = 1.1;
      }

      let slider_controls = document.createElement('div');
      slider_controls.classList.add('slider_controls');

      let swiper_pagination_container = document.createElement('div');
      swiper_pagination_container.classList.add('swiper-pagination-container');
      slider_controls.append(swiper_pagination_container);

      let swiper_pagination = document.createElement('div');
      swiper_pagination.classList.add('swiper-pagination');
      swiper_pagination_container.append(swiper_pagination);

      let swiper_nav_prev = document.createElement('div');
      swiper_nav_prev.classList.add('swiper-button-prev','button', 'button-outlined','button-secondary');
      slider_controls.append(swiper_nav_prev);

      let swiper_nav_next = document.createElement('div');
      swiper_nav_next.classList.add('swiper-button-next','button', 'button-outlined','button-secondary');
      slider_controls.append(swiper_nav_next);

      const swiper = new Swiper(swiper_item.querySelector('.block--elements'), {
        createElements: true,
        slideClass: 'card',
        grabCursor: true,
        simulateTouch: true,
        freeMode: false,
        allowTouchMove: true,
        uniqueNavElements: true,
        focusableElements: 'input, select, option, textarea, button, video, label, a, button',
        noSwipingClass: "swiper-no-swiping-block",
        mousewheel: {
          forceToAxis: true,
        },
        navigation: {
          nextEl: swiper_nav_next,
          prevEl: swiper_nav_prev,
        },
        // pagination: true,
        pagination: {
          el: swiper_pagination,
          type: "progressbar",
        },
        breakpoints: {
          280: {
            spaceBetween: 8,
            slidesPerView: slides_per_view_mob,
          },
          640: {
            spaceBetween: 24,
            slidesPerView: slides_per_view_pad,
          },
          1140: {
            spaceBetween: 24,
            slidesPerView: slides_per_view_desktop,
          },
        },
      });
      swiper_item.querySelector('.block--elements').append(slider_controls);

      if (swiper.slides.length <= 1) {
        slider_controls.classList.add('hidden')
        swiper.disable()
      }
    }



  })
}


activateBlocklistSlider(document)



// Галлерея
let  activateGallerySliders = (block) => {
  let gallery_swiper = block.querySelectorAll('.js-gallerySwiper');

  gallery_swiper.forEach(gallery => {
    let slides_per_view_desktop = 4, slides_per_view_pad = 3, slides_per_view_mob = 1.2, slides_centeredSlides = false;

    switch (true) {
      case gallery.classList.contains('gallerySwiper-v2'):

        slides_per_view_desktop = 2;
        slides_per_view_pad = 1;
        slides_per_view_mob = 'auto';
        slides_centeredSlides = false;
        break;
      case gallery.classList.contains('gallerySwiper-v3'):
        slides_per_view_desktop = 1.6;
        slides_per_view_pad = 1;
        slides_per_view_mob = 'auto';
        slides_centeredSlides = 'true';
        break;

      default:
        slides_centeredSlides = false
        slides_per_view_desktop = 3;
        slides_per_view_pad = 2;
        slides_per_view_mob = 'auto';
    }

    let slider_controls = document.createElement('div');
    slider_controls.classList.add('slider_controls');

    let swiper_pagination_container = document.createElement('div');
    swiper_pagination_container.classList.add('swiper-pagination-container');
    slider_controls.append(swiper_pagination_container);

    let swiper_pagination = document.createElement('div');
    swiper_pagination.classList.add('swiper-pagination');
    swiper_pagination_container.append(swiper_pagination);

    let swiper_nav_prev = document.createElement('div');
    swiper_nav_prev.classList.add('swiper-button-prev','button', 'button-outlined','button-secondary');
    slider_controls.append(swiper_nav_prev);

    let swiper_nav_next = document.createElement('div');
    swiper_nav_next.classList.add('swiper-button-next','button', 'button-outlined','button-secondary');
    slider_controls.append(swiper_nav_next);


    const swiper = new Swiper(gallery, {
      createElements: true,
      slidesPerView: 3,
      loop: true,
      grabCursor: true,
      simulateTouch: true,
      freeMode: false,
      allowTouchMove: true,
      mousewheel: {
        forceToAxis: true,
      },
      slideClass: 'gallery--item',
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      // pagination: true,
      pagination: {
        el: swiper_pagination,
        type: "progressbar",
      },
      breakpoints: {
        280: {
          spaceBetween: 8,
          slidesPerView: slides_per_view_mob,
        },
        640: {
          spaceBetween: 20,
          slidesPerView: slides_per_view_pad,
        },
        1140: {
          spaceBetween: 20,
          centeredSlides: slides_centeredSlides,
          slidesPerView: slides_per_view_desktop,
        },
      },

    });
    gallery.append(slider_controls);
  })
}

activateGallerySliders(document)

// Слайдер события

let  activateEventsSliders = (block) => {

    let slider_controls = document.createElement('div');
    slider_controls.classList.add('slider_controls');

    let swiper_pagination_container = document.createElement('div');
    swiper_pagination_container.classList.add('swiper-pagination-container');
    slider_controls.append(swiper_pagination_container);

    let swiper_pagination = document.createElement('div');
    swiper_pagination.classList.add('swiper-pagination');
    swiper_pagination_container.append(swiper_pagination);

    let swiper_nav_prev = document.createElement('div');
    swiper_nav_prev.classList.add('swiper-button-prev','button', 'button-outlined','button-secondary');
    slider_controls.append(swiper_nav_prev);

    let swiper_nav_next = document.createElement('div');
    swiper_nav_next.classList.add('swiper-button-next','button', 'button-outlined','button-secondary');
    slider_controls.append(swiper_nav_next);

    const swiper = new Swiper(block, {
      createElements: true,
      slidesPerView: 1,
      grabCursor: true,
      simulateTouch: true,
      freeMode: false,
      allowTouchMove: true,
      autoHeight: true,
      mousewheel: {
        forceToAxis: true,
      },
      slideClass: 'card',
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      // pagination: true,
      pagination: {
        el: swiper_pagination,
        type: "progressbar",
      },
      breakpoints: {
        320: {
          spaceBetween: 8
        },
        768: {
          slidesPerView: 2.1,
          spaceBetween: 24,
        }
      },
    });
    block.append(slider_controls);
}
if ( window.matchMedia('(max-width: 1140px)').matches ) {
  let events_swiper = document.querySelector('.block_list.content_events .block--elements');
  if(events_swiper){
    activateEventsSliders(events_swiper)
  }

}

let random = (min, max) => Math.floor(Math.random() * (max - min)) + min;

// Слайдер в image-text

let activateImageTextSlider = ( sliders ) => {
  sliders.forEach(slider => {

    let images = slider.querySelectorAll('img')

    if ( images.length > 1 ) {
      slider.classList.add('block--image-slider')
      slider.addEventListener('click', (e)=>{
        e.stopPropagation();
        e.preventDefault()
      })

      images.forEach(img => {
        img.classList.add('image_slide')
      })

      let slider_controls = document.createElement('div');
      slider_controls.classList.add('slider_controls');

      let swiper_pagination = document.createElement('div');
      swiper_pagination.classList.add('swiper-pagination');
      slider_controls.append(swiper_pagination);

      let swiper_nav_prev = document.createElement('div');
      swiper_nav_prev.classList.add('swiper-button-prev','button', 'button-outlined','button-secondary','button-dark');
      slider_controls.append(swiper_nav_prev);

      let swiper_nav_next = document.createElement('div');
      swiper_nav_next.classList.add('swiper-button-next','button', 'button-outlined','button-secondary','button-dark');
      slider_controls.append(swiper_nav_next);



      const images_slider = new Swiper(slider, {
        createElements: true,
        slidesPerView: 1,
        autoplay: {
          delay: random(2000, 5000)
        },
        // effect: "fade",
        grabCursor: true,
        simulateTouch: true,
        freeMode: false,
        allowTouchMove: true,
        loop: true,
        mousewheel: {
          forceToAxis: true,
        },
        slideClass: 'image_slide',
        navigation: {
          nextEl: swiper_nav_next,
          prevEl: swiper_nav_prev,
        },
        pagination: {
          el: swiper_pagination,
          clickable: true
        },
      });
      slider.append(slider_controls);
    }
  })

}

activateImageTextSlider(document.querySelectorAll('.block_image_text .block--image'))
activateImageTextSlider(document.querySelectorAll('.content_gallery-action .block--image'))
// Слайдер в карточках

let activateCardImagesSlider = ( sliders ) => {
  sliders.forEach(slider => {

    let card_images = slider.querySelectorAll('img')

    if ( card_images.length > 1 ) {
      slider.addEventListener('click', (e)=>{
        e.stopPropagation();
        e.preventDefault()
      })

      card_images.forEach(img => {
        img.classList.add('card--image_slide')
      })

      const card_image_slider = new Swiper(slider, {
        createElements: true,
        slidesPerView: 1,
        autoplay: {
          delay: random(1000, 3000)
        },
        effect: "fade",
        grabCursor: true,
        simulateTouch: true,
        freeMode: false,
        allowTouchMove: true,
        loop: true,
        mousewheel: {
          forceToAxis: true,
        },
        slideClass: 'card--image_slide',
        navigation: true,
        pagination: false,
      });
    }
  })

}

activateCardImagesSlider(document.querySelectorAll('.block_list .card .card--image'))




// Слайдер в табах
let activateTabsSlider = ( slider ) => {
    let tabs = slider.querySelectorAll('button')
    if ( tabs.length > 1 ) {

      tabs.forEach(tab => {
        tab.classList.add('tabs_slide')
      })

      let slider_controls = document.createElement('div');
      slider_controls.classList.add('slider_controls');

      let swiper_nav_prev = document.createElement('div');
      swiper_nav_prev.classList.add('swiper--prev','button', 'button-outlined','button-secondary');
      slider_controls.append(swiper_nav_prev);

      let swiper_nav_next = document.createElement('div');
      swiper_nav_next.classList.add('swiper--next','button', 'button-outlined','button-secondary');
      slider_controls.append(swiper_nav_next);

      const tabs_slider = new Swiper(slider.querySelector('.block--sections_container'), {
        createElements: true,
        // slidesPerView: 1,
        slidesPerView: 'auto',
        grabCursor: true,
        simulateTouch: true,
        freeMode: false,
        allowTouchMove: true,
        watchOverflow: true,
        mousewheel: {
          forceToAxis: true,
        },
        slideClass: 'tabs_slide',
        navigation: {
          nextEl: swiper_nav_next,
          prevEl: swiper_nav_prev,
        },
        on: {
          init: function (swiper) {
            swiper.slides.forEach((sl, index) => {
              sl.addEventListener('click', ()=>{
                tabs_slider.slideTo(tabs_slider.clickedIndex)
              })
            })
          }
        },
      });

      slider.appendChild(slider_controls);
    }
}
document.querySelectorAll(' .block--sections').forEach(section =>{
  activateTabsSlider(section)
})


// /* Input type file */
// function returnFileSize(number) {
//   if (number < 1024) {
//     return `${number} bytes`;
//   } else if (number >= 1024 && number < 1048576) {
//     return `${(number / 1024).toFixed(1)} KB`;
//   } else if (number >= 1048576) {
//     return `${(number / 1048576).toFixed(1)} MB`;
//   }
// }
//
// function checkFileSize(number, max_number) {
//   if(number > max_number){
//
//   }
// }
//
//
// let inputs_file = document.querySelectorAll(".js-input_file")
//
// inputs_file.forEach(input => {
//
//   let file_text = input.parentElement.querySelector(".js-changeDescriptionText")
//   let changeFileButton = input.parentElement.querySelector(".js-clearFile")
//
//   let input_max_size = parseInt(input.dataset.maxsize)
//
//   input.addEventListener("change", function(e){
//     checkFileSize(this.files[0].size, input_max_size)
//
//     file_text.textContent = input.files.item(0).name + " (" + returnFileSize(this.files[0].size) + ")";
//     input.parentElement.classList.add("loaded");
//
//   })
//
//   changeFileButton.addEventListener("click", function(e){
//     e.stopPropagation()
//     e.preventDefault()
//
//     input.value = ""
//     input.parentElement.classList.remove("loaded")
//     file_text.innerHTML = "<span>Выберите файл</span> с резюме или перетащите его в поле (doc, pdf, до 10мб)"
//   })
//
// })

gsap.registerPlugin(ScrollTrigger);

/* Lenis */
// const lenis = new Lenis({
//   duration: 1,
// })


// function raf(time) {
//   lenis.raf(time)
//   requestAnimationFrame(raf)
// }
// requestAnimationFrame(raf)

//
// lenis.on('scroll', ScrollTrigger.update)
//
// gsap.ticker.add((time)=>{
//   lenis.raf(time * 1000)
// })

if (document.querySelector('.content_animation')){
  gsap.to(".animation--row:nth-child(1) .animation--image img", {
    borderBottomRightRadius: "100%",
    borderTopRightRadius: "100%",
    borderTopLeftRadius: "100%",
    width: '453px',
    scrollTrigger: {
      trigger: ".animation--row:nth-child(1)",
      start: "top 60%",
      end: "bottom 60%",
      scrub: 2,
      markers: false,
    }
  });
  gsap.fromTo(".animation--row:nth-child(3) .animation--image img", {
    y: 100,
    borderRadius: 0,
  }, {
    borderRadius: 380,
    y: -250,
    ease: Power2.in,

    scrollTrigger: {
      trigger: ".animation--row:nth-child(3)",
      start: "top bottom",
      end: "50% 50%",
      scrub: 1,
      markers: false,
    }
  });
  gsap.to(".animation--row:not(:nth-child(4))", {
    y: -500,
    scrollTrigger: {
      trigger: ".animation--row:nth-child(4)",
      start: "60% bottom",
      end: "bottom 50%",
      scrub: 2,
      markers: false,
    }
  });
  gsap.fromTo(".animation--row:nth-child(4) .animation--image", {

    borderRadius:0,
    // width:'50%',
  },{
    borderRadius: 380,
    // width: '100%',
    scrollTrigger: {
      trigger: ".animation--row:nth-child(4)",
      start: "30% bottom",
      end: "45% 45%",
      scrub: 1,
      markers: false,
    }
  })


  let tl = gsap.timeline({
    scrollTrigger: {
      trigger: ".content_animation .animation--row:nth-child(4)",
      pin: false,
      markers: false,
      start: "-20% 70%",
      end: "40% 40%",
      scrub: 1,
    }
  })

  tl.to(".content_animation .animation--row:nth-child(4) .animation--image", {width: '100%'}, "<");
  // tl.to(".content_animation .animation--row:nth-child(4) .animation--image", {width: '50%'}, ">");

}


if (document.querySelector('.content_animation-v2')){
  if ( window.matchMedia('(min-width: 1240px)').matches ) {
    let an = gsap.timeline({
      scrollTrigger: {
        trigger: ".content_animation-v2",
        pin: false,
        markers: false,
        start: "-20% 70%",
        end: "40% 40%",
        scrub: 2,
      }
    })
    an.fromTo(".content_animation-v2 .title-1", {
      y: 300,
    }, {
      y: 0,
      duration: 1,
      ease: "sine.in",
    })
    an.fromTo(".content_animation-v2 img", {
      top: '100%',
    }, {
      duration: 1,
      top: '50%',
      ease: "sine.in",
    }, "+=0")
    an.fromTo(".content_animation-v2 .title-2", {
      y: 300,
    }, {
      y: 0,
      ease: "sine.in",
    }, "+=0")
    an.fromTo(".content_animation-v2 .subtitle", {
      y: 300,
    }, {
      y: 0,
      ease: "sine.in",
    }, "+=0")


    let an2 = gsap.timeline({
      scrollTrigger: {
        trigger: ".content_animation-v2",
        pin: false,
        markers: false,
        start: "60% 50%",
        end: "120% bottom",
        scrub: 2,
      }
    })
    an2.fromTo(".content_animation-v2 .block--wrapper", {
      y: 0,
    }, {
      y: -300,
      duration: 1,
      ease: "sine.in",
    })
    // an2.fromTo(".content_animation-v2 .title-1", {
    //   y: 0,
    // }, {
    //   y: -300,
    //   duration: 1,
    //   ease: "sine.in",
    // })
    // an2.fromTo(".content_animation-v2 img", {
    //   top: '50%',
    // }, {
    //   duration: 1,
    //   top: '-50%',
    //   ease: "sine.in",
    // })
    // an2.fromTo(".content_animation-v2 .title-2", {
    //   y: 0,
    // }, {
    //   y: -300,
    //   duration: 1,
    //   ease: "sine.in",
    // })
    // an2.fromTo(".content_animation-v2 .subtitle", {
    //   y: 0,
    // }, {
    //   y: -300,
    //   duration: 1,
    //   ease: "sine.in",
    // })
  }

}

let animation3 = document.querySelector('.content_animation-3')
if (animation3) {

  gsap.fromTo(".content_animation-3 .animation--row:nth-child(1) .animation--title", {

    x: '-100%',
  },{
    x: '100%',
    scrollTrigger: {
      trigger: ".content_animation-3",
      pin: false,
      markers: false,
      start: "0 60%",
      end: "120% top",
      scrub: 4,
      duration: 1,
      ease: "power1.inOut",
    }
  })
  gsap.fromTo(".content_animation-3 .animation--row:nth-child(2) .animation--title", {

    x: '100%',
  },{
    x: '-100%',
    scrollTrigger: {
      trigger: ".content_animation-3",
      pin: false,
      markers: false,
      start: "0 60%",
      end: "120% top",
      scrub: 4,
      duration: 1,
      ease: "power1.inOut",
    }
  })
}


let INFRASTRUCTURE_PLACEMARKS = {
  0: {
    title: "Название объекта",
    description: "Краткое описание объекта",
    image: "../assets/img/2.jpg",
    link: "/",
    other: ""
  },
  1: {
    title: "1 Просторные денники для лошадей с самыми высокими требованиями",
    description: "Светлые, просторные конюшни с денниками 3×3.8 метра, снабженными системой отопления, вентиляцией и автопоилками. ",
    image: "../assets/img/hourse.jpg",
    link: "/",
    other: "/"
  },
  2: {
    title: "2",
    description: "Краткое описание объекта",
    image: "../assets/img/g2.jpg",
    link: "/",
    other: ""
  },
  3: {
    title: "3",
    description: "Краткое описание объекта",
    image: "../assets/img/1.jpg",
    link: "/",
    other: ""
  },
  4: {
    title: "4",
    description: "Краткое описание объекта",
    image: "../assets/img/hourse.jpg",
    link: "/",
    other: ""
  },
  5: {
    title: "5",
    description: "Краткое описание объекта",
    image: "../assets/img/hourse.jpg",
    link: "/",
    other: ""
  },
  6: {
    title: "6",
    description: "Краткое описание объекта",
    image: "../assets/img/hourse.jpg",
    link: "/",
    other: ""
  },
  7: {
    title: "7",
    description: "Краткое описание объекта",
    image: "../assets/img/hourse.jpg",
    link: "/",
    other: ""
  },
  8: {
    title: "8",
    description: "Краткое описание объекта",
    image: "../assets/img/hourse.jpg",
    link: "/",
    other: ""
  },
}
let infrastructureBlock = document.querySelector('.content_infrastructure')
if(infrastructureBlock){
  // TABS
  let tabs = infrastructureBlock.querySelectorAll('.block--sections button')
  tabs.forEach(tab =>{
    let popupNumber = infrastructureBlock.querySelector('.popup .popup--number')
    let placemarks = infrastructureBlock.querySelectorAll('.placemark')
    tab.addEventListener('click', (e)=>{
      PopupManager.close('popup_for_infrastructure')
      let a = e.currentTarget.dataset.target
      let p = ' .placemark[data-content='+'"'+a+'"'+'] '
      let placemark = infrastructureBlock.querySelector(p)

        PopupManager.open('popup_for_infrastructure', {
          id: placemark.getAttribute('data-id')
        })

          placemarks.forEach(pl =>{
          placemark === pl ? pl.classList.add('is_active') : pl.classList.remove('is_active')
          popupNumber.dataset.number = placemark.getAttribute('data-id')

        })
      })
      placemarks.forEach(pl =>{
          pl.addEventListener('click', (e)=>{
            popupNumber.dataset.number = e.currentTarget.getAttribute('data-id')
          })
      })
    })

//   placemark
  let placemarks = infrastructureBlock.querySelectorAll('.placemark')
  placemarks.forEach(pl =>{
    pl.addEventListener('click', (e)=>{
      placemarks.forEach(pl =>{
        e.currentTarget === pl ? pl.classList.add('is_active') : pl.classList.remove('is_active')
      })
    })
  })
}

let review_videos = document.querySelectorAll('.block_list .card video')

review_videos.forEach(video => {
  video.addEventListener('mouseenter', (e)=>{
    video.play()
  })
  video.addEventListener('mouseleave', ()=>{
    video.pause()
  })
})

if ( window.matchMedia('(max-width: 768px)').matches ) {
  let card_reviews = document.querySelectorAll('.card--image:has(video)')
  card_reviews.forEach(card_with_video => {
    let card_reviews_video = card_with_video.querySelector('video')
    card_reviews_video.addEventListener('click', (e)=>{
      e.stopPropagation()

      if ( card_reviews_video.paused ) {
        card_reviews_video.play()
        card_reviews_video.removeAttribute("muted")
      } else {
        card_reviews_video.pause()
        card_reviews_video.setAttribute("muted", "")
      }
    })
  })
}

/* Map Yandex Places */

let map_road = document.getElementById('map_road')
let content_road_map_block = document.querySelector('.content_road_map')

if ( map_road && content_road_map_block) {
  ymaps.ready(init_road_map);
  function init_road_map(){
    var myMap = new ymaps.Map("map_road", {
      center: [56.026875, 38.279307],
      zoom: 12,
      controls: ['zoomControl'],
    });


    myMap.geoObjects
      .add(new ymaps.Placemark([56.026875, 38.279307], {
        balloonContent: 'Horseka resort',
        hintContent: 'Horseka resort'
      }, {
        iconLayout: 'default#imageWithContent',
        iconImageHref: '/assets/img/vector.svg',
        iconImageSize: [48, 48],
        iconImageOffset: [-12, -12],
      }))

    myMap.behaviors.disable('scrollZoom')
    if ( window.matchMedia("(max-width: 768px)").matches ) {
      myMap.behaviors
        .disable('drag')
        .enable('multiTouch');
    }
  }


}

/* Map Yandex Places */

let map_tour = document.getElementById('map_tour')
let content_tour_map_block = document.querySelector('.content_tour_map')


if ( map_tour && content_tour_map_block) {
  ymaps.ready(init_tour_maps);

  function init_tour_maps() {

    let map_tour_settings = {};

    if (  typeof SITE_MAP_SETTINGS === 'undefined' || SITE_MAP_SETTINGS === null ){
      map_tour_settings = {
        coords: [56.026875, 38.279307],
      };
    } else {
      map_tour_settings = {...SITE_MAP_SETTINGS}
    }

    // if (  typeof TOUR_MAP_ARRAY === 'undefined' || TOUR_MAP_ARRAY === null ){
      let TOUR_MAP_ARRAY = [
        {
          coords: [56.026875, 38.279307],
          title: "Поселок Ивановское",
          text: "Долгое и подробное описание, которое может занимать до трех строк текста, а может уходить в ограничение",
        }, {
          coords: [56.001380, 38.184928],
          title: "День 2",
          text: "Текст с кратким описанием достропримечательности",
        }, {
          coords: [56.046615, 37.983746],
          title: "День 3",
          text: "Краткий текст о достопримечательности 2",
        },
      ]
    // }

    let tour_map = new ymaps.Map("map_tour", {
      center: map_tour_settings.coords,
      zoom: 16,
      controls: [],
    },);

    tour_map.behaviors.disable('scrollZoom');

    if ( window.matchMedia("(max-width: 768px)").matches ) {
      tour_map.behaviors
        .disable('drag')
        .enable('multiTouch');
    }

    let places_on_map = new ymaps.GeoObjectCollection({}, {});

    let icon_layout = ymaps.templateLayoutFactory.createClass(
      '<svg transform="translate(14,0)" class="placemark"  width="46" height="46" viewBox="0 0 96 96" fill="none" data-active="$[properties.data_active]" xmlns="http://www.w3.org/2000/svg">' +
      '<circle cx="44.9992" cy="45.0002" r="30.8" fill="white"/>' +
      '<circle cx="44.9992" cy="45.0002" r="27.8" fill="" stroke="#FC563B" stroke-width="6"/>' +
      '<text class="map--placemark_content" x="34" y="59"  fill="#FC563B" font-size="42px">$[properties.iconContent]</text>'+
      '</svg>'
    )

    let line_coords = []

    let accent_color = window.getComputedStyle(document.documentElement).getPropertyValue('--accent-2')

    let tours_sections = content_tour_map_block.querySelector('.block--sections_container')

    for(let i = 0; i < TOUR_MAP_ARRAY.length; i++){

      let section_item = document.createElement('button')
      section_item.textContent = TOUR_MAP_ARRAY[i].title

      line_coords.push(TOUR_MAP_ARRAY[i].coords)

      let placemark = new ymaps.Placemark(TOUR_MAP_ARRAY[i].coords,{
          balloonHeader: TOUR_MAP_ARRAY[i].title,
          balloonContent: TOUR_MAP_ARRAY[i].text,
          iconContent: i + 1,
          placemark_index: i,
          data_active: 'active'
        },{
          iconLayout: "default#imageWithContent",
          iconImageHref: '/assets/img/icons/Union.svg',
          iconImageClipRect: [[0,0], [56, 56]],
          iconImageSize: [56, 56],
          iconImageOffset: [-28, -28],
          iconContentOffset: [0, 0],
          iconContentLayout: icon_layout,
          zIndex: 3,
          zIndexHover: 4,
          balloonShadow: false,
          balloonPanelMaxMapArea: 0,
          hasBalloon: false,
          clicked_placemark: true,
          opacity: 1
        }
      )

      tours_sections.appendChild(section_item)

      section_item.addEventListener('click',(e)=>{
        tours_sections.querySelectorAll("button").forEach(it => {
          it === section_item ? it.classList.add('is_active') : it.classList.remove('is_active')
        })
        PopupManager.open('popup_for_tour', {placemark: placemark.properties._data})
        tour_map.panTo([placemark.geometry._coordinates])

        placemark.properties.set('data_active', 'active');

        places_on_map.each(function (geoObject) {
          if (geoObject !== placemark) {
            geoObject.properties.set('data_active', 'not_active');
          }
        })
      })

      placemark.events.add([
        'balloonopen', 'balloonclose', 'hintopen', 'hintclose', 'dragstart', 'dragend', 'click'
      ], function (e) {

        placemark.properties.set('data_active', 'active');

        places_on_map.each(function (geoObject) {
          if (geoObject !== placemark) {
            geoObject.properties.set('data_active', 'not_active');
          }
        })
        tours_sections.querySelectorAll("button").forEach(it => {
          it === section_item ? it.classList.add('is_active') : it.classList.remove('is_active')
        })
        PopupManager.open('popup_for_tour', {placemark: placemark.properties._data})
        tour_map.panTo([placemark.geometry._coordinates])
      });
      places_on_map.add(placemark)
    }

    tour_map.geoObjects.add(places_on_map);

    // Линия для тура
    let dashed_polyline = new ymaps.Polyline([
      ...line_coords
    ], {}, {
      strokeColor: accent_color.toString(),
      strokeWidth: 2,
      strokeStyle: 'dash',
      strokeOpacity: 0.6
    });

    tour_map.geoObjects.add(dashed_polyline);
    tour_map.setBounds(places_on_map.getBounds());

  }
}


// Accordion
let activateAccordion = (block) => {
  let accordionItems = block.querySelectorAll(".accordion");
  accordionItems.forEach(item => {
    let active_items = item.querySelectorAll('a')

    active_items.forEach(i => {
      i.addEventListener("click", (e)=>{
        e.stopPropagation()
      })
    })

    item.addEventListener("click", function(e){

      accordionItems.forEach(it => {
        it !== e.currentTarget ? it.classList.remove('is_open') : it.classList.toggle('is_open')
      });

    })
  })
}

activateAccordion(document)



let blockFilter = document.querySelectorAll('.filter')


function resetSelect(block){
  let select = block.querySelectorAll('.select')
  let reset = block.querySelector('[type="reset"]')

  reset.addEventListener('click', (e)=>{
    if(select.length >= 1){
      select.forEach(sel=>{
        sel.querySelector('.select--button').textContent = sel.querySelector('.select--option').textContent
        sel.querySelectorAll('.select--option').forEach(s =>{
          s.classList.remove('is_selected')
        })
      })
    }
  })
}
if (blockFilter){
  blockFilter.forEach(block =>{
    resetSelect(block)
  })



}


let blockSections = document.querySelectorAll('.block--sections')

blockSections.forEach(block =>{
  let tabs = block.querySelectorAll('button')
  tabs.forEach( tab =>{
    tab.addEventListener("click", (e) =>{
      tabs.forEach(t =>{
        t === e.currentTarget ? t.classList.add('is_active')  : t.classList.remove('is_active')
      })
    })
  })
  document.addEventListener("DOMContentLoaded", () => {
    if(tabs){
      // tabs[0].click()
    }
  });
})


let blockTabs = document.querySelectorAll('.js-tabs')
blockTabs.forEach(block =>{
  let tabs = block.querySelectorAll('.block--sections [data-target]')
  let item = block.querySelectorAll('[data-content]')
  tabs .forEach(tab =>{

    tab.addEventListener("click", t =>{
      t = t.currentTarget
      item.forEach(i =>{
        t.dataset.target === i.dataset.content ? i.classList.remove('hidden')  : i.classList.add('hidden')
      })
    })
  })
  tabs[0].click()

})
